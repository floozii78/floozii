// ==UserScript==
// @name         Noct
// @author       PolisBotSoft
// @description  Noct Secure Loader
// @version      3.1.0
// @match        http://*.grepolis.com/game/*
// @match        https://*.grepolis.com/game/*
// @exclude      forum.*.grepolis.*/*
// @exclude      wiki.*.grepolis.*/*
// @grant        GM_xmlhttpRequest
// @connect      noct-api.grepo-soft.workers.dev
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    const API_URL = 'https://noct-api.grepo-soft.workers.dev';

    // Get player ID from Grepolis
    function getPlayerId() {

        if (typeof Game !== 'undefined' && Game.player_id) {
            return Game.player_id;
        }

        if (typeof MM !== 'undefined' && MM.getModels) {
            try {
                const player = MM.getModels().Player;
                if (player && player[0] && player[0].id) {
                    return player[0].id;
                }
            } catch (e) {
                console.log('[Noct Debug] Error getting player ID from MM object:', e);
            }
        }
        const urlMatch = window.location.href.match(/[?&]p=(\d+)/);
        if (urlMatch) {
            return parseInt(urlMatch[1]);
        }
        return null;
    }

    // Show error message
    function showError(title, message) {
        console.error(`[Noct] ${title}: ${message}`);
        if (typeof alert !== 'undefined') {
            alert(`Noct - ${title}\n\n${message}`);
        }
    }

    // Execute bot code
    function executeBot(code) {
        try {
            // Execute bot code immediately
            const executor = new Function(code);
            executor();
        } catch (error) {
            console.error('[Noct] Execution error:', error.message);
            showError('Bot Error', 'Failed to initialize bot. Please refresh the page.');
        }
    }

    // Always load bot - subscription checks happen within the bot
    function loadBot() {
        const playerId = getPlayerId();

        if (!playerId) {
            setTimeout(loadBot, 2000);
            return;
        }

        // Always fetch and load bot code - subscription checks happen within the bot
        const botUrl = `${API_URL}/api/bot?userId=${playerId}&t=${Date.now()}`;
        GM_xmlhttpRequest({
            method: 'GET',
            url: botUrl,
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate'
            },
            onload: function (botResponse) {
                if (botResponse.status === 200) {
                    executeBot(botResponse.responseText);
                } else if (botResponse.status === 403) {
                    // Bot access denied (subscription issues)
                    showError('Access Denied', 'Your subscription is not active. Please renew to use Noct.');
                } else {
                    showError('Load Error', 'Failed to load bot code. Please try refreshing the page.');
                }
            },
            onerror: function () {
                showError('Connection Error', 'Failed to download bot from Noct servers. Check your internet connection.');
            }
        });
    }

    // Wait for page to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadBot);
    } else {
        loadBot();
    }
})();

