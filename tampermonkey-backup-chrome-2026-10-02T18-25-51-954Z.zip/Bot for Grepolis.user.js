// ==UserScript==
// @name           Bot for Grepolis
// @namespace      Bot for Grepolis
// @description    Bot for Grepolis
// @author         green elephant
// @version        2.5.2
// @run-at         document-end
// @updateUrl      https://botsoft.org/en/bot/gef.user.js
// @include        http://*.grepolis.com/*
// @include        https://*.grepolis.com/*
// @exclude        forum.*.grepolis.*/*
// @exclude        wiki.*.grepolis.*/*
// @connect        botsoft.org
// @grant          GM_xmlhttpRequest
// ==/UserScript==

(function(){

	var request = null;

	if ((typeof GM=="object") && (typeof GM.xmlHttpRequest=="function")){
		request = GM.xmlHttpRequest;
	}
	else if (typeof GM_xmlhttpRequest=="function"){
		request = GM_xmlhttpRequest
	}
	else{
		console.log("Sorry, your browser dont supprt GM_xmlhttpRequest");
		return;
	}

	var hash = Math.random().toString(36).substr(2),
		eventRequest  = hash + "request",
		eventResponse = hash + "response";

	document.addEventListener(eventRequest, function(e){
		var params = (typeof e.detail=="object") ? e.detail : JSON.parse(e.detail);
		params.onload = function(response){
			var out = {
				id    : params.id,
				status: response.status,
				text  : response.responseText
			}
			var cloned = (typeof cloneInto=="function") ? cloneInto(out, document) : out;
			var e2 = new CustomEvent(eventResponse, {detail: cloned, bubblies: true});
			document.dispatchEvent(e2);
		}
		if (typeof e.detail.headers=="object") params.headers = e.detail.headers;
		request(params);
	});


	var init = {
		url   : "https://botsoft.org/en/bot/ajaxv2/",
		method: "POST",
		data  : JSON.stringify({
			method: "bot:login:hash",
			data  : {hash: hash}
		}),
		onload: function(response){
			var script = document.createElement("script");
			script.type = "text/javascript";
			script.src = "//botsoft.org/bot/bot.js?nocache="+Math.random();
			document.getElementsByTagName("head")[0].appendChild(script);
		}
	}
	request(init);


})();