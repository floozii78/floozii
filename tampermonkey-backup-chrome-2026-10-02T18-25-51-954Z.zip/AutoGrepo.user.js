// ==UserScript==
// @name AutoGrepo
// @namespace https://autogrepo.com/
// @version 2.2
// @description autogrepo
// @include                     http://*.grepolis.com/*
// @include                     https://*.grepolis.com/*
// @exclude                     forum.*.grepolis.*/*
// @exclude                     wiki.*.grepolis.*/*
// @require     https://code.jquery.com/jquery-1.12.4.js
// @require     https://code.jquery.com/ui/1.12.1/jquery-ui.js
// ==/UserScript==


// ============  Configurable / Costumizable variables ===============
var enableAutoStarters = false;

var agp_forceFullDisableAutoLogin = true;
var agp_autoLogin = false;
var agp_autoLoginDelay = 600; //SECONDS will not be exactly this delay

var agp_autoWordConnect = "";
var agp_autoWorldConnectDelay = 300; //SECONDS will not be exactly this delay

var agp_AutoAuthorizeBotCode = "AUTO_AUTH_CODE"; //(optional to edit) Replace this with your Auto-Auth Code if you keep getting a pop-up asking you to authorize the bot





//===============  DO NOT EDIT ANYTHING BELOW ======================

let rest = "";
if(enableAutoStarters){
      rest += "&agp_forceFullDisableAutoLogin=" + (agp_forceFullDisableAutoLogin ? 'true' : 'false') + "&agp_autoLogin=" + (agp_autoLogin ? 'true' : 'false') + "&agp_autoLoginDelay=" + (agp_autoLoginDelay ? agp_autoLoginDelay : '') + "&agp_autoWordConnect=" + (agp_autoWordConnect ? agp_autoWordConnect : '') + "&agp_autoWorldConnectDelay=" + (agp_autoWorldConnectDelay ? agp_autoWorldConnectDelay :'');
}
if(agp_AutoAuthorizeBotCode && agp_AutoAuthorizeBotCode !== "" && agp_AutoAuthorizeBotCode !== atob("QVVUT19BVVRIX0NPREU=")){ // DO NOT EDIT THIS!
   rest += "&agp_AutoAuthorizeBotCode=" + agp_AutoAuthorizeBotCode;
}

var script = document.createElement("script");
script.type = "text/javascript";
script.src = "//autogrepo.com/thescript/provider/bot/bot.js?nocache=" + Math.random() + rest;
document.getElementsByTagName("head")[0].appendChild(script);


