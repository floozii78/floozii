// ==UserScript==
// @name         Floozii Alarme
// @namespace    http://tampermonkey.net/
// @version      0.6
// @description  Alarme continue, haut-parleur déplaçable, panneau déplaçable et réductible en petite icône
// @match        https://*.grepolis.com/game/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
    'use strict';

    const KEY = 'grepo_alarme_reglages';
    const defauts = {
        son: 'sirene', volume: 0.5, urlPerso: '', actif: true,
        hpX: null, hpY: 120,          // position du haut-parleur d'alerte
        pnX: 10, pnY: null,           // position du panneau / de la petite icône
        pnReduit: false,              // panneau réduit ou non
        fnX: null, fnY: 60, fnOuvert: false, // fenêtre des attaques entrantes
        mkX: 60, mkY: 100, mkOuvert: false,  // fenêtre du marché
        odX: 100, odY: 140, odOuvert: false, odFiltre: 'tous', // fenêtre des ordres
        autoAccepte: false,           // a confirmé avoir compris le risque de l'automatisation
        farmActif: false, farmMin: 5  // collecte automatique des villages paysans
    };
    let cfg;
    try { cfg = Object.assign({}, defauts, JSON.parse(localStorage.getItem(KEY) || '{}')); }
    catch (e) { cfg = Object.assign({}, defauts); }
    const sauver = () => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {} };


    // ---------- Minuteur qui continue en arrière-plan ----------
    // Les onglets cachés ralentissent setInterval (jusqu'à 1 fois par minute). Un Web Worker
    // n'est pas ralenti de la même façon : on s'en sert pour cadencer tous les minuteurs.
    let wk = null;
    const rappels = {};
    let idMinuteur = 0;
    try {
        const src = 'const t={};onmessage=e=>{const d=e.data;if(t[d.id])clearInterval(t[d.id]);t[d.id]=setInterval(()=>postMessage(d.id),d.ms);};';
        wk = new Worker(URL.createObjectURL(new Blob([src], { type: 'application/javascript' })));
        wk.onmessage = e => { const f = rappels[e.data]; if (f) { try { f(); } catch (err) { console.log('Floozii Alarme :', err); } } };
    } catch (e) { wk = null; }
    function intervalle(fn, ms) {
        if (wk) { const id = ++idMinuteur; rappels[id] = fn; wk.postMessage({ id, ms }); return id; }
        return window.setInterval(fn, ms);
    }

    // ---------- Utilitaires : placement et déplacement ----------
    function caler(el, x, y) {
        el.style.left = Math.max(0, Math.min(x, window.innerWidth - el.offsetWidth)) + 'px';
        el.style.top = Math.max(0, Math.min(y, window.innerHeight - el.offsetHeight)) + 'px';
    }

    // Rend "el" déplaçable en le tirant par "poignee". Un simple clic appelle onClic.
    function deplacable(el, poignee, setPos, onClic) {
        let drag = null;
        poignee.addEventListener('pointerdown', e => {
            if (e.target.closest('button, input, select')) return;
            drag = { dx: e.clientX - el.offsetLeft, dy: e.clientY - el.offsetTop, x0: e.clientX, y0: e.clientY, bouge: false };
            poignee.setPointerCapture(e.pointerId);
            poignee.style.cursor = 'grabbing';
        });
        poignee.addEventListener('pointermove', e => {
            if (!drag) return;
            if (Math.abs(e.clientX - drag.x0) + Math.abs(e.clientY - drag.y0) > 5) drag.bouge = true;
            if (drag.bouge) setPos(e.clientX - drag.dx, e.clientY - drag.dy);
        });
        poignee.addEventListener('pointerup', () => {
            if (!drag) return;
            poignee.style.cursor = 'grab';
            if (drag.bouge) sauver();
            else if (onClic) onClic();
            drag = null;
        });
    }


    // ---------- Lecture robuste des noms de villes / joueurs ----------
    function sansHtml(v) { return String(v).replace(/<[^>]*>/g, '').trim(); }

    function nomTown(b, pre) {
        if (!b) return null;
        const suf = pre === 'origin' ? 'origin' : 'destination';
        // 1. champs réels vus dans Grepolis : town_name_origin / town_name_destination
        if (b['town_name_' + suf]) return sansHtml(b['town_name_' + suf]);
        // 2. le lien HTML contient aussi le nom : link_origin / link_destination
        if (b['link_' + suf]) { const t = sansHtml(b['link_' + suf]); if (t) return t; }
        // 3. anciens noms possibles
        const directs = pre === 'origin'
            ? ['origin_town_name', 'origin_name', 'from_town_name', 'source_town_name']
            : ['target_town_name', 'destination_town_name', 'target_name'];
        for (const k of directs) if (b[k]) return sansHtml(b[k]);
        // 4. par identifiant (marche pour les villes du joueur)
        const id = pre === 'origin'
            ? (b.origin_town_id || b.home_town_id)
            : (b.target_town_id || b.destination_town_id);
        if (id) {
            try { const t = ITowns.getTown(id); if (t) return t.getName(); } catch (e) {}
            return 'ville #' + id;
        }
        return null;
    }

    function nomJoueur(b, pre) {
        if (!b) return null;
        for (const k of Object.keys(b)) {
            const l = k.toLowerCase();
            if (b[k] && typeof b[k] === 'string' && /player|owner/.test(l) && /name/.test(l)
                && (l.includes(pre) || l.includes('source') || l.includes('from') || l === 'player_name')) {
                return sansHtml(b[k]);
            }
        }
        return null;
    }

    // ---------- Sons générés ----------
    let ctx, master = null, audioPerso = null;
    function audio() {
        if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
        if (ctx.state === 'suspended') ctx.resume();
        return ctx;
    }
    function sortie() {
        const c = audio();
        if (!master) { master = c.createGain(); master.connect(c.destination); }
        return master;
    }
    // ---------- Support YouTube (lecteur caché) ----------
    let ytFrame = null;
    function idYouTube(url) {
        const m = (url || '').match(/(?:youtu\.be\/|[?&]v=|\/embed\/|\/shorts\/)([\w-]{11})/);
        return m ? m[1] : null;
    }
    function volumeYouTube() {
        if (!ytFrame || !ytFrame.contentWindow) return;
        try {
            ytFrame.contentWindow.postMessage(JSON.stringify({
                event: 'command', func: 'setVolume', args: [Math.round(cfg.volume * 100)]
            }), '*');
        } catch (e) {}
    }
    function jouerYouTube(id) {
        arreterYouTube();
        ytFrame = document.createElement('iframe');
        ytFrame.src = `https://www.youtube.com/embed/${id}?autoplay=1&loop=1&playlist=${id}&enablejsapi=1&controls=0`;
        ytFrame.allow = 'autoplay; encrypted-media';
        ytFrame.style.cssText = 'position:fixed;width:1px;height:1px;left:-10px;top:-10px;opacity:0;pointer-events:none;border:0;';
        ytFrame.onload = () => { volumeYouTube(); setTimeout(volumeYouTube, 800); setTimeout(volumeYouTube, 2000); };
        document.body.appendChild(ytFrame);
    }
    function arreterYouTube() {
        if (ytFrame) { ytFrame.remove(); ytFrame = null; }
    }

    function coupeSons() {
        if (master) { try { master.disconnect(); } catch (e) {} master = null; }
        if (audioPerso) { audioPerso.pause(); audioPerso = null; }
        arreterYouTube();
    }
    function note(freq, debut, duree, type = 'sine', vol = 1) {
        const c = audio();
        const o = c.createOscillator();
        const g = c.createGain();
        const t = c.currentTime + debut;
        o.type = type;
        o.frequency.value = freq;
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(Math.max(0.0001, cfg.volume * vol), t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + duree);
        o.connect(g);
        g.connect(sortie());
        o.start(t);
        o.stop(t + duree + 0.05);
    }

    // "duree" = durée d'un cycle en secondes : le suivant démarre juste après
    const SONS = {
        sirene: { nom: 'Sirène', duree: 2, jouer() {
            for (let i = 0; i < 2; i++) { note(600, i, 0.5, 'sawtooth', 0.6); note(900, i + 0.5, 0.5, 'sawtooth', 0.6); }
        } },
        bip: { nom: 'Bips rapides', duree: 1.5, jouer() {
            for (let i = 0; i < 6; i++) note(1000, i * 0.25, 0.15, 'square', 0.4);
        } },
        cloche: { nom: 'Cloche', duree: 1.6, jouer() {
            for (let i = 0; i < 2; i++) { note(880, i * 0.8, 0.7, 'sine'); note(1320, i * 0.8, 0.7, 'sine', 0.5); }
        } },
        corne: { nom: 'Corne de guerre', duree: 3, jouer() {
            note(220, 0, 1.2, 'sawtooth', 0.7); note(330, 0.1, 1.1, 'sawtooth', 0.4);
            note(220, 1.5, 1.2, 'sawtooth', 0.7); note(330, 1.6, 1.1, 'sawtooth', 0.4);
        } },
        perso: { nom: 'Son perso (URL)', duree: 0, jouer() {
            if (!cfg.urlPerso) { alert('Colle d\'abord l\'URL d\'un fichier audio (mp3, ogg, wav).'); return false; }
            const yt = idYouTube(cfg.urlPerso);
            if (yt) { jouerYouTube(yt); return; }
            if (audioPerso) audioPerso.pause();
            audioPerso = new Audio(cfg.urlPerso);
            audioPerso.volume = cfg.volume;
            audioPerso.loop = true; // le son perso tourne en boucle
            audioPerso.play().catch(e => console.log('Alarme : lecture impossible', e));
        } }
    };

    // ---------- Alarme continue ----------
    let minuteur = null;
    let enCours = false;
    let test = false;

    function cycle() {
        if (!enCours) return;
        const son = SONS[cfg.son] || SONS.sirene;
        if (son.jouer() === false) { arreterAlarme(); return; }
        if (son.duree > 0) {
            // On relance un peu avant la fin pour que le son soit sans coupure
            minuteur = setTimeout(cycle, Math.max(200, son.duree * 1000 - 300));
        }
    }

    function demarrerAlarme() {
        if (enCours) return;
        enCours = true;
        cycle();
        majWidget();
    }
    function arreterAlarme() {
        enCours = false;
        if (minuteur) { clearTimeout(minuteur); minuteur = null; }
        coupeSons();
        test = false;
        majWidget();
    }

    // ---------- Détection des attaques ----------
    function nomVille(attrs) {
        try {
            const t = ITowns.getTown(attrs.target_town_id);
            if (t) return t.getName();
        } catch (e) {}
        return attrs.target_town_name || 'Ville inconnue';
    }

    function attaquesEntrantes() {
        try {
            const mouvements = MM.getModels().MovementsUnits || {};
            return Object.values(mouvements)
                .filter(m => m.attributes && m.attributes.type === 'attack_incoming')
                .map(m => ({ id: String(m.attributes.id), ville: nomVille(m.attributes), brut: m.attributes }));
        } catch (e) {
            const el = document.querySelector('.activity.commands.incoming_attacks .count');
            if (el) {
                const n = parseInt(el.textContent, 10) || 0;
                return Array.from({ length: n }, (_, i) => ({ id: 'dom' + i, ville: 'Ville inconnue', brut: null }));
            }
            return [];
        }
    }

    const connues = new Set();
    let attaquesActuelles = [];

    function verifier() {
        if (!cfg.actif) return;
        attaquesActuelles = attaquesEntrantes();
        const ids = attaquesActuelles.map(a => a.id);
        const nouvelles = ids.filter(id => !connues.has(id));
        ids.forEach(id => connues.add(id));
        Array.from(connues).forEach(id => { if (!ids.includes(id)) connues.delete(id); });

        if (nouvelles.length > 0) {
            demarrerAlarme();
            const msg = `⚠️ ${nouvelles.length} nouvelle(s) attaque(s) en approche !`;
            if (typeof HumanMessage !== 'undefined') HumanMessage.error(msg);
        }
        // Plus d'attaque : on coupe tout
        if (ids.length === 0 && !test && enCours) arreterAlarme();
        majWidget();
        majFenetre();
    }
    intervalle(verifier, 5000);

    // ---------- Haut-parleur d'alerte déplaçable ----------
    const widget = document.createElement('div');
    widget.style.cssText = 'position:fixed;z-index:10000;display:none;align-items:center;gap:8px;background:#7a0000;color:#fff;padding:6px 12px;border-radius:24px;font:bold 13px sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.6);cursor:grab;user-select:none;touch-action:none;';
    widget.innerHTML = '<span id="hp-icone" style="font-size:28px;line-height:1">🔊</span><span id="hp-noms"></span>';
    document.body.appendChild(widget);

    function placerWidget() {
        caler(widget, cfg.hpX === null ? window.innerWidth - 260 : cfg.hpX, cfg.hpY);
    }

    function majWidget() {
        const noms = {};
        attaquesActuelles.forEach(a => { noms[a.ville] = (noms[a.ville] || 0) + 1; });
        let texte = Object.entries(noms).map(([v, n]) => n > 1 ? `${v} (×${n})` : v).join(', ');
        if (test && !texte) texte = 'Ville test';
        const visible = enCours || texte;
        widget.style.display = visible ? 'flex' : 'none';
        widget.querySelector('#hp-noms').textContent = texte;
        widget.querySelector('#hp-icone').textContent = enCours ? '🔊' : '🔇';
        widget.style.background = enCours ? '#7a0000' : '#444';
        if (visible) placerWidget();
    }

    deplacable(widget, widget,
        (x, y) => { cfg.hpX = x; cfg.hpY = y; caler(widget, x, y); },
        () => arreterAlarme() // simple clic = couper l'alarme
    );


    // ---------- Fenêtre des attaques entrantes ----------
    const fen = document.createElement('div');
    fen.style.cssText = 'position:fixed;z-index:10001;display:none;background:#222;color:#fff;border-radius:8px;font:11px sans-serif;box-shadow:0 2px 12px rgba(0,0,0,.7);user-select:none;min-width:320px;max-width:90vw;';
    fen.innerHTML = `
        <div id="fn-entete" style="display:flex;align-items:center;gap:6px;padding:6px 8px;background:#7a0000;border-radius:8px 8px 0 0;cursor:grab;touch-action:none;">
            <b id="fn-titre" style="flex:1;white-space:nowrap">📋 Attaques entrantes</b>
            <button id="fn-brut" title="Afficher les données brutes dans la console (F12)" style="cursor:pointer;font-size:10px">🔍</button>
            <button id="fn-fermer" title="Fermer" style="cursor:pointer;padding:0 6px">✕</button>
        </div>
        <div id="fn-corps" style="max-height:40vh;overflow:auto;padding:6px 8px"></div>
        <div id="fn-plan" style="border-top:1px solid #555;padding:6px 8px">
            <b>⏱ Planifier un envoi</b>
            <div style="display:flex;gap:4px;margin:4px 0">
                <input id="pl-nom" type="text" placeholder="Nom (ex : Attaque Sparte)" style="flex:1;min-width:0;font-size:11px;user-select:text">
                <input id="pl-heure" type="time" step="1" style="font-size:11px;user-select:text">
                <button id="pl-ajout" style="cursor:pointer;font-size:11px">➕</button>
            </div>
            <details style="margin-bottom:4px">
                <summary style="cursor:pointer;color:#ccc">Calculer depuis l'heure d'arrivée</summary>
                <div style="display:flex;gap:4px;margin-top:4px;align-items:center">
                    Arrivée <input id="pl-arr" type="time" step="1" style="font-size:11px;user-select:text">
                    Trajet <input id="pl-traj" type="text" placeholder="hh:mm:ss" size="8" style="font-size:11px;user-select:text">
                    <button id="pl-calc" style="cursor:pointer;font-size:11px">→ départ</button>
                </div>
            </details>
            <div id="pl-liste"></div>
            <div style="color:#999;margin-top:4px">Heures = horloge de ton ordinateur. Alerte sonore 10 s avant puis à l'heure : c'est toi qui envoies. Pour un envoi automatique, utilise la fenêtre d'attaque du jeu.</div>
        </div>`;
    document.body.appendChild(fen);

    const fnCorps = fen.querySelector('#fn-corps');
    const choisir = (o, ...cles) => {
        for (const k of cles) if (o && o[k] !== undefined && o[k] !== null && o[k] !== '') return o[k];
        return null;
    };
    const maintenant = () => (typeof Timestamp !== 'undefined' && Timestamp.now) ? Timestamp.now() : Date.now() / 1000;
    const dureeTxt = sec => {
        sec = Math.max(0, Math.floor(sec));
        const p = n => String(n).padStart(2, '0');
        return `${p(Math.floor(sec / 3600))}:${p(Math.floor(sec % 3600 / 60))}:${p(sec % 60)}`;
    };

    function placerFenetre() {
        caler(fen, cfg.fnX === null ? window.innerWidth - fen.offsetWidth - 20 : cfg.fnX, cfg.fnY);
    }

    function majFenetre() {
        if (!cfg.fnOuvert) return;
        const liste = attaquesActuelles.slice().sort((a, b) =>
            (choisir(a.brut, 'arrival_at') || 1e12) - (choisir(b.brut, 'arrival_at') || 1e12));
        fen.querySelector('#fn-titre').textContent = `📋 Attaques entrantes (${liste.length})`;

        if (!liste.length) {
            fnCorps.textContent = 'Aucune attaque en approche. ✅';
            placerFenetre();
            return;
        }
        const now = maintenant();
        const table = document.createElement('table');
        table.style.cssText = 'border-collapse:collapse;width:100%';
        table.innerHTML = '<tr style="text-align:left;color:#f99"><th>Cible</th><th>Origine</th><th>Joueur</th><th>Arrivée</th><th>Reste</th></tr>';
        liste.forEach(a => {
            const b = a.brut || {};
            const arr = choisir(b, 'arrival_at');
            const origine = nomTown(b, 'origin');
            const joueur = nomJoueur(b, 'origin');
            const ally = choisir(b, 'origin_alliance_name', 'origin_town_alliance_name');
            const cmd = choisir(b, 'command_type');
            const cases = [
                a.ville,
                origine || '?',
                (joueur || '?') + (ally ? ` [${ally}]` : ''),
                arr ? new Date(arr * 1000).toLocaleTimeString('fr-FR') : '?',
                arr ? dureeTxt(arr - now) : '?'
            ];
            const tr = document.createElement('tr');
            tr.style.borderTop = '1px solid #444';
            if (arr && arr - now < 60) tr.style.color = '#ff6666';
            cases.forEach((t, i) => {
                const td = document.createElement('td');
                td.style.padding = '3px 6px 3px 0';
                td.textContent = t;
                if (i === 4) td.style.fontFamily = 'monospace';
                if (i === 0 && cmd) td.title = 'Type : ' + cmd;
                tr.appendChild(td);
            });
            table.appendChild(tr);
        });
        fnCorps.replaceChildren(table);
        placerFenetre();
    }
    intervalle(majFenetre, 1000);

    function ouvrirFenetre(ouvert) {
        cfg.fnOuvert = ouvert;
        sauver();
        fen.style.display = ouvert ? 'block' : 'none';
        if (ouvert) { attaquesActuelles = attaquesEntrantes(); majFenetre(); placerFenetre(); }
    }

    fen.querySelector('#fn-fermer').onclick = () => ouvrirFenetre(false);
    fen.querySelector('#fn-brut').onclick = () => {
        console.log('Floozii Alarme - données brutes des attaques :', attaquesActuelles.map(a => a.brut));
        alert('Données affichées dans la console (touche F12).');
    };
    deplacable(fen, fen.querySelector('#fn-entete'),
        (x, y) => { cfg.fnX = x; cfg.fnY = y; caler(fen, x, y); }
    );



    // ---------- Planificateur d'envois (rappel à l'heure précise) ----------
    const KEYP = 'floozii_planif';
    let planif = [];
    try { planif = JSON.parse(localStorage.getItem(KEYP) || '[]'); } catch (e) {}
    planif = planif.filter(p => p.ts > Date.now() - 1000); // on oublie ce qui est déjà passé
    const sauverP = () => { try { localStorage.setItem(KEYP, JSON.stringify(planif)); } catch (e) {} };

    const hms = n => { n = ((Math.round(n) % 86400) + 86400) % 86400; const p = x => String(x).padStart(2, '0'); return `${p(Math.floor(n / 3600))}:${p(Math.floor(n % 3600 / 60))}:${p(n % 60)}`; };
    const versSec = t => { const a = String(t).trim().split(':').map(Number); if (a.some(isNaN) || !a.length) return null; while (a.length < 3) a.unshift(0); return a[0] * 3600 + a[1] * 60 + a[2]; };

    function prochainTs(heure) {
        const sec = versSec(heure);
        if (sec === null) return null;
        const d = new Date();
        d.setHours(0, 0, 0, 0);
        let ts = d.getTime() + sec * 1000;
        if (ts <= Date.now()) ts += 86400000; // heure déjà passée aujourd'hui : demain
        return ts;
    }

    function majPlanif() {
        if (!cfg.fnOuvert) return;
        const div = fen.querySelector('#pl-liste');
        if (!planif.length) { div.textContent = 'Aucun envoi planifié.'; return; }
        const frag = document.createDocumentFragment();
        planif.slice().sort((a, b) => a.ts - b.ts).forEach(p => {
            const reste = (p.ts - Date.now()) / 1000;
            const ligne = document.createElement('div');
            ligne.style.cssText = 'display:flex;gap:6px;align-items:center;padding:2px 0;border-top:1px solid #444' + (reste <= 10 ? ';color:#ff6666;font-weight:bold' : '');
            const nom = document.createElement('span');
            nom.style.flex = '1';
            nom.textContent = p.label || 'Envoi';
            const heure = document.createElement('span');
            const d = new Date(p.ts);
            heure.textContent = d.toLocaleTimeString('fr-FR') + (d.toDateString() !== new Date().toDateString() ? ' (demain)' : '');
            const cpt = document.createElement('span');
            cpt.style.fontFamily = 'monospace';
            cpt.textContent = dureeTxt(reste);
            const x = document.createElement('button');
            x.textContent = '✕';
            x.style.cssText = 'cursor:pointer;font-size:10px';
            x.onclick = () => { planif = planif.filter(q => q.id !== p.id); sauverP(); majPlanif(); };
            ligne.append(nom, heure, cpt, x);
            frag.appendChild(ligne);
        });
        div.replaceChildren(frag);
    }

    function declencher(p) {
        p.fait = true;
        sauverP();
        SONS.sirene.jouer();
        if (typeof HumanMessage !== 'undefined') HumanMessage.error(`⏰ ENVOIE MAINTENANT : ${p.label || 'envoi'}`);
    }

    // Vérifie les heures 4 fois par seconde (même fenêtre fermée)
    intervalle(() => {
        const maintenantMs = Date.now();
        let change = false;
        planif.forEach(p => {
            const reste = (p.ts - maintenantMs) / 1000;
            if (!p.avert && reste <= 10 && reste > 0) {
                p.avert = true; change = true;
                for (let i = 0; i < 3; i++) note(1000, i * 0.3, 0.15, 'square', 0.5);
                if (typeof HumanMessage !== 'undefined') HumanMessage.success(`⏱ Dans 10 s : ${p.label || 'envoi'}`);
            }
            if (!p.fait && reste <= 0) declencher(p); // secours si le setTimeout a été retardé
            // à moins d'1 s : on programme le déclenchement à la milliseconde près
            if (!p.prog && !p.fait && reste <= 1) {
                p.prog = true;
                setTimeout(() => declencher(p), Math.max(0, p.ts - Date.now()));
            }
        });
        const avant = planif.length;
        planif = planif.filter(p => p.ts > maintenantMs - 15000); // on garde 15 s après l'heure
        if (planif.length !== avant || change) sauverP();
        majPlanif();
    }, 250);

    fen.querySelector('#pl-ajout').onclick = () => {
        const heure = fen.querySelector('#pl-heure').value;
        if (!heure) { alert('Choisis une heure d\'envoi.'); return; }
        const ts = prochainTs(heure);
        if (!ts) return;
        planif.push({ id: Date.now() + Math.random(), label: fen.querySelector('#pl-nom').value.trim(), ts, avert: false, fait: false, prog: false });
        fen.querySelector('#pl-nom').value = '';
        sauverP();
        majPlanif();
    };
    fen.querySelector('#pl-calc').onclick = () => {
        const arr = versSec(fen.querySelector('#pl-arr').value);
        const traj = versSec(fen.querySelector('#pl-traj').value);
        if (arr === null || traj === null || !fen.querySelector('#pl-arr').value) { alert('Renseigne l\'heure d\'arrivée et la durée du trajet (hh:mm:ss).'); return; }
        fen.querySelector('#pl-heure').value = hms(arr - traj);
    };


    // ---------- Envoi programmé directement dans la fenêtre d'attaque du jeu ----------
    // Le panneau se colle sous la fenêtre où tu choisis les unités. À l'heure choisie, le script
    // clique lui-même sur le bouton d'envoi du jeu : c'est le jeu qui envoie, avec tes unités.
    const UNITES = ['sword', 'slinger', 'archer', 'hoplite', 'rider', 'chariot', 'catapult', 'minotaur', 'manticore', 'centaur',
        'pegasus', 'harpy', 'medusa', 'zyklop', 'cerberus', 'fury', 'griffin', 'calydonian_boar', 'satyr', 'spartoi', 'ladon',
        'godsent', 'big_transporter', 'small_transporter', 'bireme', 'attack_ship', 'demolition_ship', 'trireme', 'colonize_ship',
        'sea_monster', 'militia'];

    function unitesChoisies(win) {
        const res = {};
        win.querySelectorAll('input').forEach(inp => {
            if (inp.closest('.floozii-prog')) return;
            let id = null;
            const m = (inp.className || '').match(/unit_type_([a-z_]+)/);
            if (m && UNITES.includes(m[1])) id = m[1];
            else if (UNITES.includes(inp.name)) id = inp.name;
            else {
                const cont = inp.closest('[class*="unit_container"], [class*="index_unit"], [class*="unit_"]');
                const c = cont && UNITES.find(u => new RegExp('(^|\\s)' + u + '(\\s|$)').test(cont.className));
                if (c) id = c;
            }
            const n = parseInt(inp.value, 10) || 0;
            if (id && n > 0) res[id] = (res[id] || 0) + n;
        });
        return res;
    }

    function boutonEnvoi(win) {
        const visible = el => el && el.offsetParent !== null && !el.closest('.floozii-prog');
        const sels = ['#btn_attack_town', '.btn_attack', '.btn_send', '.btn_support', 'a.attack', 'a.support'];
        for (const sel of sels) {
            const el = Array.from(win.querySelectorAll(sel)).find(visible);
            if (el) return el;
        }
        // à défaut : un bouton dont le texte ressemble à "Attaquer / Envoyer / Soutenir"
        return Array.from(win.querySelectorAll('a, button, input[type="button"], input[type="submit"], .button_new, .btn'))
            .find(el => visible(el) && /^(attaquer|attaque|attack|envoyer|send|soutenir|soutien|support|aider)$/i.test((el.textContent || el.value || '').trim())) || null;
    }

    function cliquer(el) {
        ['mousedown', 'mouseup', 'click'].forEach(t =>
            el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
    }

    function estFenetreAttaque(el) {
        if (el.classList.contains('attack_support_window')) return true;
        return el.classList.contains('gpwindow_content')
            && Object.keys(unitesChoisies(el)).length + el.querySelectorAll('input[class*="unit_type_"]').length >= 2
            && !!boutonEnvoi(el);
    }

    const panneauxProg = []; // { win, box, ts, actif, avert, fait }

    function injecterProg(win) {
        if (win.dataset.floozii) return;
        win.dataset.floozii = '1';
        const box = document.createElement('div');
        box.className = 'floozii-prog';
        box.style.cssText = 'position:fixed;z-index:10002;background:#222;color:#fff;border:1px solid #7a0000;border-radius:6px;padding:5px 8px;font:11px sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.6);max-width:420px;';
        box.innerHTML = `
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                <b>⏱ Envoi programmé</b>
                <input class="fz-heure" type="time" step="1" style="font-size:11px">
                <button class="fz-go" style="cursor:pointer;font-size:11px">Programmer</button>
                <button class="fz-stop" style="cursor:pointer;font-size:11px;display:none">✕ Annuler</button>
            </div>
            <div class="fz-etat" style="margin-top:3px;color:#ccc"></div>`;
        document.body.appendChild(box);
        ['keydown', 'keyup', 'keypress'].forEach(t => box.addEventListener(t, e => e.stopPropagation()));

        const p = { win, box, ts: 0, actif: false, avert: false, fait: false, prog: false };
        panneauxProg.push(p);

        box.querySelector('.fz-go').onclick = () => {
            const heure = box.querySelector('.fz-heure').value;
            if (!heure) { alert('Choisis l\'heure d\'envoi.'); return; }
            if (!Object.keys(unitesChoisies(win)).length) { alert('Sélectionne d\'abord des unités dans la fenêtre d\'attaque.'); return; }
            if (!boutonEnvoi(win)) { alert('Bouton d\'envoi du jeu introuvable dans cette fenêtre. Envoie-moi le nom de ce bouton pour que j\'adapte le script.'); return; }
            if (!cfg.autoAccepte) {
                if (!confirm('L\'envoi programmé agit à ta place dans le jeu. Grepolis peut sanctionner les scripts qui automatisent des actions (risque de bannissement du compte). Tu en assumes le risque ?')) return;
                cfg.autoAccepte = true; sauver();
            }
            p.ts = prochainTs(heure);
            p.actif = true; p.avert = false; p.fait = false; p.prog = false;
            box.querySelector('.fz-stop').style.display = 'inline-block';
        };
        box.querySelector('.fz-stop').onclick = () => { p.actif = false; box.querySelector('.fz-stop').style.display = 'none'; };
    }

    function declencherProg(p) {
        p.fait = true;
        p.actif = false;
        p.box.querySelector('.fz-stop').style.display = 'none';
        const echec = msg => {
            SONS.sirene.jouer();
            if (typeof HumanMessage !== 'undefined') HumanMessage.error('⏰ Envoi programmé impossible : ' + msg);
            p.box.querySelector('.fz-etat').textContent = '⚠️ ' + msg;
        };
        if (!document.body.contains(p.win)) { echec('la fenêtre d\'attaque a été fermée.'); return; }
        if (!Object.keys(unitesChoisies(p.win)).length) { echec('plus aucune unité sélectionnée.'); return; }
        const btn = boutonEnvoi(p.win);
        if (!btn) { echec('bouton d\'envoi introuvable.'); return; }
        cliquer(btn);
        if (typeof HumanMessage !== 'undefined') HumanMessage.success('🤖 Ordre envoyé à l\'heure prévue (vérifie dans Ordres).');
        p.box.querySelector('.fz-etat').textContent = '✅ Envoyé à ' + new Date().toLocaleTimeString('fr-FR');
    }

    let compteScan = 0;
    intervalle(() => {
        // 1. détecte les nouvelles fenêtres d'attaque (1 fois par seconde)
        if (compteScan++ % 4 === 0) {
            document.querySelectorAll('.attack_support_window, .gpwindow_content').forEach(el => {
                if (el.dataset.floozii || el.closest('[data-floozii]') || el.querySelector('[data-floozii]')) return;
                if (estFenetreAttaque(el)) injecterProg(el);
            });
        }
        // 2. met à jour chaque panneau
        for (let i = panneauxProg.length - 1; i >= 0; i--) {
            const p = panneauxProg[i];
            if (!document.body.contains(p.win)) {
                if (p.actif && !p.fait) { declencherProg(p); } // fenêtre fermée avant l'heure : on prévient
                if (!p.actif) { p.box.remove(); panneauxProg.splice(i, 1); }
                continue;
            }
            // position : collé sous la fenêtre du jeu
            const cont = p.win.closest('.ui-dialog') || p.win.closest('.gpwindow_content') || p.win;
            const r = cont.getBoundingClientRect();
            p.box.style.display = r.width ? 'block' : 'none';
            p.box.style.left = Math.max(0, r.left) + 'px';
            const h = p.box.offsetHeight;
            p.box.style.top = (r.bottom + 4 + h > window.innerHeight ? Math.max(0, r.bottom - h - 4) : r.bottom + 4) + 'px';
            p.box.style.width = Math.min(420, Math.max(300, r.width)) + 'px';

            const etat = p.box.querySelector('.fz-etat');
            if (p.actif) {
                const reste = (p.ts - Date.now()) / 1000;
                const u = Object.entries(unitesChoisies(p.win)).map(([k, v]) => `${v} ${k}`).join(', ') || 'aucune unité !';
                etat.textContent = `Envoi dans ${dureeTxt(reste)} · ${u}`;
                if (!p.avert && reste <= 10 && reste > 0) {
                    p.avert = true;
                    for (let k = 0; k < 3; k++) note(1000, k * 0.3, 0.15, 'square', 0.5);
                }
                // à moins d'1 s : déclenchement programmé à la milliseconde près
                if (reste <= 1 && !p.prog) {
                    p.prog = true;
                    setTimeout(() => { if (p.actif && !p.fait) declencherProg(p); }, Math.max(0, p.ts - Date.now()));
                }
                if (reste <= 0 && !p.fait) declencherProg(p); // secours
            } else if (!p.fait) {
                const u = Object.entries(unitesChoisies(p.win)).map(([k, v]) => `${v} ${k}`).join(', ');
                etat.textContent = u ? `Unités détectées : ${u}` : 'Sélectionne des unités puis choisis l\'heure.';
            }
        }
    }, 250);

    // ---------- Fenêtre du marché (transactions) ----------
    const KEYJ = 'floozii_journal_marche';
    let journal = [];
    try { journal = JSON.parse(localStorage.getItem(KEYJ) || '[]'); } catch (e) {}
    const sauverJ = () => { try { localStorage.setItem(KEYJ, JSON.stringify(journal.slice(-100))); } catch (e) {} };
    let marcheActuel = [];

    const nomParId = (id, defaut) => {
        try { const t = ITowns.getTown(id); if (t) return t.getName(); } catch (e) {}
        return defaut || '?';
    };

    // Cherche dans tous les modèles du jeu les mouvements de type "commerce"
    function lireTransactions() {
        const res = [];
        try {
            Object.entries(MM.getModels()).forEach(([nom, coll]) => {
                if (!coll || typeof coll !== 'object') return;
                Object.values(coll).forEach(m => {
                    const b = m && m.attributes;
                    if (!b) return;
                    const type = String(b.type || b.command_type || '');
                    const src = b.res || b.resources || b;
                    const aRess = ['wood', 'stone', 'iron'].some(k => src[k] !== undefined);
                    if (!(/trade|market/i.test(type) || (aRess && b.arrival_at))) return;
                    res.push({
                        id: nom + ':' + (b.id !== undefined ? b.id : (b.origin_town_id + '-' + b.arrival_at)),
                        type,
                        origine: nomTown(b, 'origin'),
                        cible: nomTown(b, 'target'),
                        ress: { wood: src.wood || 0, stone: src.stone || 0, iron: src.iron || 0 },
                        arr: choisir(b, 'arrival_at'),
                        brut: b
                    });
                });
            });
        } catch (e) {}
        return res;
    }

    function scanMarche() {
        marcheActuel = lireTransactions();
        const ids = new Set(marcheActuel.map(t => t.id));
        let change = false;
        marcheActuel.forEach(t => {
            if (!journal.some(j => j.id === t.id && !j.fini)) {
                journal.push({ id: t.id, type: t.type, origine: t.origine, cible: t.cible, ress: t.ress, arr: t.arr, vu: Date.now(), fini: false });
                change = true;
            }
        });
        journal.forEach(j => { if (!j.fini && !ids.has(j.id)) { j.fini = true; change = true; } });
        if (change) sauverJ();
    }
    intervalle(scanMarche, 5000);

    const mk = document.createElement('div');
    mk.style.cssText = 'position:fixed;z-index:10001;display:none;background:#222;color:#fff;border-radius:8px;font:11px sans-serif;box-shadow:0 2px 12px rgba(0,0,0,.7);user-select:none;min-width:340px;max-width:90vw;';
    mk.innerHTML = `
        <div id="mk-entete" style="display:flex;align-items:center;gap:6px;padding:6px 8px;background:#1f5f2a;border-radius:8px 8px 0 0;cursor:grab;touch-action:none;">
            <b id="mk-titre" style="flex:1;white-space:nowrap">💱 Marché</b>
            <button id="mk-vider" title="Vider l'historique" style="cursor:pointer;font-size:10px">🗑</button>
            <button id="mk-brut" title="Données brutes dans la console (F12)" style="cursor:pointer;font-size:10px">🔍</button>
            <button id="mk-fermer" title="Fermer" style="cursor:pointer;padding:0 6px">✕</button>
        </div>
        <div id="mk-corps" style="max-height:60vh;overflow:auto;padding:6px 8px"></div>`;
    document.body.appendChild(mk);
    const mkCorps = mk.querySelector('#mk-corps');

    const nb = n => Number(n || 0).toLocaleString('fr-FR');
    const ressTxt = r => `${nb(r.wood)}🪵 ${nb(r.stone)}🪨 ${nb(r.iron)}🪙`;

    function tableau(entetes, lignes) {
        const table = document.createElement('table');
        table.style.cssText = 'border-collapse:collapse;width:100%';
        table.innerHTML = '<tr style="text-align:left;color:#9f9">' + entetes.map(h => `<th>${h}</th>`).join('') + '</tr>';
        lignes.forEach(cases => {
            const tr = document.createElement('tr');
            tr.style.borderTop = '1px solid #444';
            cases.forEach(t => {
                const td = document.createElement('td');
                td.style.padding = '3px 6px 3px 0';
                td.textContent = t;
                tr.appendChild(td);
            });
            table.appendChild(tr);
        });
        return table;
    }
    const titreSection = txt => {
        const d = document.createElement('div');
        d.style.cssText = 'font-weight:bold;margin:6px 0 3px;color:#cfc';
        d.textContent = txt;
        return d;
    };

    function placerMarche() {
        caler(mk, cfg.mkX === null ? 60 : cfg.mkX, cfg.mkY);
    }

    function majMarche() {
        if (!cfg.mkOuvert) return;
        const now = maintenant();
        mk.querySelector('#mk-titre').textContent = `💱 Marché (${marcheActuel.length} en cours)`;
        const frag = document.createDocumentFragment();

        frag.appendChild(titreSection('En cours'));
        if (!marcheActuel.length) {
            const d = document.createElement('div');
            d.textContent = 'Aucune transaction en cours.';
            frag.appendChild(d);
        } else {
            const tri = marcheActuel.slice().sort((a, b) => (a.arr || 1e12) - (b.arr || 1e12));
            frag.appendChild(tableau(['De', 'Vers', 'Ressources', 'Arrivée', 'Reste'],
                tri.map(t => [t.origine, t.cible, ressTxt(t.ress),
                    t.arr ? new Date(t.arr * 1000).toLocaleTimeString('fr-FR') : '?',
                    t.arr ? dureeTxt(t.arr - now) : '?'])));
        }

        const fini = journal.filter(j => j.fini).slice(-30).reverse();
        frag.appendChild(titreSection(`Historique (${fini.length})`));
        if (!fini.length) {
            const d = document.createElement('div');
            d.textContent = 'Rien pour le moment.';
            frag.appendChild(d);
        } else {
            frag.appendChild(tableau(['De', 'Vers', 'Ressources', 'Heure'],
                fini.map(j => [j.origine, j.cible, ressTxt(j.ress),
                    j.arr ? new Date(j.arr * 1000).toLocaleString('fr-FR') : new Date(j.vu).toLocaleString('fr-FR')])));
        }
        mkCorps.replaceChildren(frag);
        placerMarche();
    }
    intervalle(majMarche, 1000);

    function ouvrirMarche(ouvert) {
        cfg.mkOuvert = ouvert;
        sauver();
        mk.style.display = ouvert ? 'block' : 'none';
        if (ouvert) { scanMarche(); majMarche(); placerMarche(); }
    }

    mk.querySelector('#mk-fermer').onclick = () => ouvrirMarche(false);
    mk.querySelector('#mk-vider').onclick = () => { journal = journal.filter(j => !j.fini); sauverJ(); majMarche(); };
    mk.querySelector('#mk-brut').onclick = () => {
        try { console.log('Floozii Alarme - modèles du jeu :', Object.keys(MM.getModels())); } catch (e) {}
        console.log('Floozii Alarme - transactions trouvées :', marcheActuel.map(t => t.brut));
        alert('Données affichées dans la console (touche F12).');
    };
    deplacable(mk, mk.querySelector('#mk-entete'),
        (x, y) => { cfg.mkX = x; cfg.mkY = y; caler(mk, x, y); }
    );


    // ---------- Fenêtre des ordres en temps réel ----------
    const TYPES_ORDRES = {
        attack_incoming: '⚔️ Attaque entrante', support_incoming: '🛡️ Soutien entrant',
        attack: '⚔️ Attaque', support: '🛡️ Soutien', attack_land: '⚔️ Attaque terrestre', attack_sea: '⚔️ Attaque navale',
        attack_takeover: '🏛️ Conquête', revolt: '🔥 Révolte', espionage: '🕵️ Espionnage', espionage_incoming: '🕵️ Espion entrant',
        colonization: '🏛️ Colonisation', abort: '↩️ Annulé', trade: '💱 Commerce',
        attack_returning: '↩️ Retour (attaque)', support_returning: '↩️ Retour (soutien)', return: '↩️ Retour'
    };
    const categorieOrdre = type => {
        const t = String(type).toLowerCase();
        if (/incoming/.test(t)) return 'entrant';
        if (/return|back|abort/.test(t)) return 'retour';
        if (/trade|market/.test(t)) return 'commerce';
        return 'sortant';
    };

    function lireOrdres() {
        const res = [];
        const vus = new Set();
        try {
            Object.entries(MM.getModels()).forEach(([nom, coll]) => {
                if (!/movement|command|trade/i.test(nom) || !coll || typeof coll !== 'object') return;
                Object.values(coll).forEach(m => {
                    const b = m && m.attributes;
                    if (!b || !b.arrival_at) return;
                    const id = nom + ':' + b.id;
                    if (vus.has(id)) return;
                    vus.add(id);
                    const type = String(b.type || b.command_type || nom);
                    res.push({
                        type,
                        label: b.command_name || null,
                        cat: categorieOrdre(type),
                        origine: nomTown(b, 'origin'),
                        cible: nomTown(b, 'target'),
                        joueur: nomJoueur(b, 'origin'),
                        arr: b.arrival_at,
                        brut: b
                    });
                });
            });
        } catch (e) {}
        return res.sort((a, b) => a.arr - b.arr);
    }
    let ordresActuels = [];

    const od = document.createElement('div');
    od.style.cssText = 'position:fixed;z-index:10001;display:none;background:#222;color:#fff;border-radius:8px;font:11px sans-serif;box-shadow:0 2px 12px rgba(0,0,0,.7);user-select:none;min-width:400px;max-width:90vw;';
    od.innerHTML = `
        <div id="od-entete" style="display:flex;align-items:center;gap:6px;padding:6px 8px;background:#1f3f7a;border-radius:8px 8px 0 0;cursor:grab;touch-action:none;">
            <b id="od-titre" style="flex:1;white-space:nowrap">📜 Ordres</b>
            <select id="od-filtre" style="font-size:10px">
                <option value="tous">Tous</option>
                <option value="entrant">Entrants</option>
                <option value="sortant">Sortants</option>
                <option value="retour">Retours</option>
                <option value="commerce">Commerce</option>
            </select>
            <button id="od-fermer" title="Fermer" style="cursor:pointer;padding:0 6px">✕</button>
        </div>
        <div id="od-corps" style="max-height:60vh;overflow:auto;padding:6px 8px"></div>`;
    document.body.appendChild(od);
    const odCorps = od.querySelector('#od-corps');
    od.querySelector('#od-filtre').value = cfg.odFiltre;

    function placerOrdres() {
        caler(od, cfg.odX === null ? 100 : cfg.odX, cfg.odY);
    }

    function majOrdres() {
        if (!cfg.odOuvert) return;
        ordresActuels = lireOrdres();
        const now = maintenant();
        const liste = ordresActuels.filter(o => cfg.odFiltre === 'tous' || o.cat === cfg.odFiltre);
        od.querySelector('#od-titre').textContent = `📜 Ordres (${liste.length}/${ordresActuels.length})`;

        if (!liste.length) {
            odCorps.textContent = 'Aucun ordre en cours.';
            placerOrdres();
            return;
        }
        const table = document.createElement('table');
        table.style.cssText = 'border-collapse:collapse;width:100%';
        table.innerHTML = '<tr style="text-align:left;color:#9cf"><th>Type</th><th>De</th><th>Vers</th><th>Joueur</th><th>Arrivée</th><th>Reste</th></tr>';
        liste.forEach(o => {
            const reste = o.arr - now;
            const tr = document.createElement('tr');
            tr.style.borderTop = '1px solid #444';
            if (/attack/.test(o.type) && o.cat === 'entrant') tr.style.color = reste < 60 ? '#ff4444' : '#ff9999';
            else if (o.cat === 'retour') tr.style.color = '#aaa';
            [
                TYPES_ORDRES[o.type] || o.label || o.type,
                o.origine || '?',
                o.cible || '?',
                o.joueur || '',
                new Date(o.arr * 1000).toLocaleTimeString('fr-FR'),
                dureeTxt(reste)
            ].forEach((t, i) => {
                const td = document.createElement('td');
                td.style.padding = '3px 6px 3px 0';
                td.textContent = t;
                if (i === 5) td.style.fontFamily = 'monospace';
                tr.appendChild(td);
            });
            table.appendChild(tr);
        });
        odCorps.replaceChildren(table);
        placerOrdres();
    }
    intervalle(majOrdres, 1000);

    function ouvrirOrdres(ouvert) {
        cfg.odOuvert = ouvert;
        sauver();
        od.style.display = ouvert ? 'block' : 'none';
        if (ouvert) { majOrdres(); placerOrdres(); }
    }

    od.querySelector('#od-fermer').onclick = () => ouvrirOrdres(false);
    od.querySelector('#od-filtre').onchange = e => { cfg.odFiltre = e.target.value; sauver(); majOrdres(); };
    deplacable(od, od.querySelector('#od-entete'),
        (x, y) => { cfg.odX = x; cfg.odY = y; caler(od, x, y); }
    );


    // ---------- Collecte automatique des villages paysans ----------
    let farmProchain = 0;
    let farmEnCours = false;
    let farmSuivantFn = null;
    let farmAt = 0;
    let farmEtat = '';

    // Villages débloqués, prêts à être collectés, avec une de tes villes située sur la même île
    function villagesPrets() {
        const now = maintenant();
        const M = MM.getModels();
        const farms = {};
        Object.values(M.FarmTown || {}).forEach(m => { if (m && m.attributes) farms[m.attributes.id] = m.attributes; });
        const villes = Object.entries(ITowns.getTowns()).map(([id, t]) => ({
            id: parseInt(id, 10), x: t.getIslandCoordinateX(), y: t.getIslandCoordinateY()
        }));
        const res = [];
        Object.values(M.FarmTownPlayerRelation || {}).forEach(m => {
            const a = m && m.attributes;
            if (!a || a.relation_status !== 1 || (a.lootable_at || 0) > now) return;
            const f = farms[a.farm_town_id];
            if (!f) return;
            const ville = villes.find(v => v.x === f.island_x && v.y === f.island_y);
            if (ville) res.push({ farm: a.farm_town_id, ville: ville.id });
        });
        return res;
    }

    function arreterFarm() {
        farmSuivantFn = null;
        farmEnCours = false;
    }

    function collecteFarm() {
        if (!cfg.farmActif || farmEnCours) return;
        let liste = [];
        try { liste = villagesPrets(); } catch (e) { console.log('Floozii Alarme : lecture des villages impossible', e); }
        if (!liste.length) { farmEtat = 'Aucun village prêt'; return; }
        farmEnCours = true;
        let i = 0;
        const suivant = () => {
            if (!cfg.farmActif) { arreterFarm(); return; }
            if (i >= liste.length) { farmEnCours = false; farmEtat = `Terminé (${liste.length} villages)`; return; }
            const v = liste[i++];
            try {
                gpAjax.ajaxPost('farm_town_info', 'claim_load', {
                    target_id: v.farm, claim_type: 'normal', time: cfg.farmMin * 60, town_id: v.ville, nlreq_id: 0
                });
            } catch (e) { console.log('Floozii Alarme : collecte impossible', e); }
            farmEtat = `Collecte ${i}/${liste.length}`;
            // pause aléatoire de 10 à 30 secondes entre deux collectes
            farmAt = Date.now() + (10 + Math.random() * 20) * 1000;
            farmSuivantFn = suivant;
        };
        suivant();
    }

    intervalle(() => {
        const el = document.getElementById('al-farm-etat');
        if (!cfg.farmActif) { if (el) el.textContent = ''; return; }
        if (farmEnCours && farmSuivantFn && Date.now() >= farmAt) { const f = farmSuivantFn; farmSuivantFn = null; f(); }
        if (Date.now() >= farmProchain) {
            collecteFarm();
            farmProchain = Date.now() + cfg.farmMin * 60000;
        }
        if (el) el.textContent = farmEnCours ? farmEtat : `${farmEtat ? farmEtat + ' · ' : ''}prochaine : ${dureeTxt((farmProchain - Date.now()) / 1000)}`;
    }, 1000);

    // ---------- Panneau de réglages (déplaçable + réductible) ----------
    const panneau = document.createElement('div');
    panneau.style.cssText = 'position:fixed;z-index:9999;background:#222;color:#fff;border-radius:8px;font:11px sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.6);user-select:none;';
    panneau.innerHTML = `
        <div id="al-entete" style="display:flex;align-items:center;gap:6px;cursor:grab;touch-action:none;">
            <span id="al-icone" style="font-size:20px;line-height:1">🔔</span>
            <b id="al-titre" style="flex:1;white-space:nowrap">Floozii Alarme</b>
            <button id="al-reduire" title="Réduire" style="cursor:pointer;padding:0 6px;line-height:16px">–</button>
        </div>
        <div id="al-corps" style="margin-top:6px;width:150px">
            <label><input type="checkbox" id="al-actif"> Activée</label><br>
            <select id="al-son" style="width:100%;margin:3px 0;font-size:11px">
                ${Object.entries(SONS).map(([k, s]) => `<option value="${k}">${s.nom}</option>`).join('')}
            </select>
            <input type="range" id="al-vol" min="0" max="1" step="0.05" style="width:100%;margin:0">
            <input type="text" id="al-url" placeholder="URL du son perso" style="width:100%;box-sizing:border-box;font-size:11px">
            <button id="al-fen" style="margin-top:4px;width:100%;font-size:11px">📋 Attaques entrantes</button>
            <button id="al-mk" style="margin-top:4px;width:100%;font-size:11px">💱 Marché</button>
            <label style="display:block;margin-top:5px"><input type="checkbox" id="al-farm"> 🌾 Collecte auto</label>
            <select id="al-farm-min" style="width:100%;font-size:11px"><option value="5">toutes les 5 min</option><option value="10">toutes les 10 min</option></select>
            <div id="al-farm-etat" style="color:#9c9;font-size:10px"></div>
            <button id="al-od" style="margin-top:4px;width:100%;font-size:11px">📜 Ordres</button>
            <button id="al-test" style="margin-top:4px;width:100%;font-size:11px">▶ Tester</button>
        </div>`;
    document.body.appendChild(panneau);

    const $ = id => panneau.querySelector('#' + id);
    const entete = $('al-entete');

    function placerPanneau() {
        const y = cfg.pnY === null ? window.innerHeight - panneau.offsetHeight - 10 : cfg.pnY;
        caler(panneau, cfg.pnX, y);
    }

    function appliquerReduit() {
        const r = cfg.pnReduit;
        $('al-corps').style.display = r ? 'none' : 'block';
        $('al-titre').style.display = r ? 'none' : 'block';
        $('al-reduire').style.display = r ? 'none' : 'inline-block';
        $('al-icone').style.fontSize = r ? '26px' : '20px';
        panneau.style.padding = r ? '4px 6px' : '6px 8px';
        panneau.style.borderRadius = r ? '24px' : '8px';
        panneau.title = r ? 'Cliquer pour ouvrir le panneau (glisser pour déplacer)' : '';
        placerPanneau();
    }

    $('al-actif').checked = cfg.actif;
    $('al-son').value = cfg.son;
    $('al-vol').value = cfg.volume;
    $('al-url').value = cfg.urlPerso;

    $('al-actif').onchange = e => { cfg.actif = e.target.checked; sauver(); if (!cfg.actif) arreterAlarme(); };
    $('al-son').onchange = e => { cfg.son = e.target.value; sauver(); };
    $('al-vol').oninput = e => { cfg.volume = parseFloat(e.target.value); sauver(); if (audioPerso) audioPerso.volume = cfg.volume; volumeYouTube(); };
    $('al-url').onchange = e => { cfg.urlPerso = e.target.value.trim(); sauver(); };
    $('al-fen').onclick = () => ouvrirFenetre(!cfg.fnOuvert);
    $('al-mk').onclick = () => ouvrirMarche(!cfg.mkOuvert);
    $('al-farm').checked = cfg.farmActif;
    $('al-farm-min').value = String(cfg.farmMin);
    $('al-farm').onchange = e => {
        if (e.target.checked && !cfg.autoAccepte) {
            if (!confirm('La collecte automatique agit à ta place dans le jeu. Grepolis peut sanctionner les scripts qui automatisent des actions (risque de bannissement du compte). Tu en assumes le risque ?')) { e.target.checked = false; return; }
            cfg.autoAccepte = true;
        }
        cfg.farmActif = e.target.checked;
        sauver();
        if (cfg.farmActif) { farmEtat = ''; farmProchain = Date.now(); } else { arreterFarm(); farmEtat = ''; }
    };
    $('al-farm-min').onchange = e => { cfg.farmMin = parseInt(e.target.value, 10); sauver(); farmProchain = Date.now() + cfg.farmMin * 60000; };
    $('al-od').onclick = () => ouvrirOrdres(!cfg.odOuvert);
    $('al-test').onclick = () => {
        try {
            test = true;
            if (enCours) arreterAlarme(); // repart proprement si une alarme tourne déjà
            test = true;
            demarrerAlarme();
        } catch (e) {
            console.log('Floozii Alarme : test impossible', e);
            alert('Le test a échoué : ' + e.message);
        }
    };

    $('al-reduire').onclick = () => { cfg.pnReduit = true; sauver(); appliquerReduit(); };

    deplacable(panneau, entete,
        (x, y) => { cfg.pnX = x; cfg.pnY = y; caler(panneau, x, y); },
        () => { if (cfg.pnReduit) { cfg.pnReduit = false; sauver(); appliquerReduit(); } } // clic sur l'icône = ouvrir
    );

    appliquerReduit();
    placerWidget();
    if (cfg.farmActif) farmProchain = Date.now() + 5000;
    if (cfg.fnOuvert) ouvrirFenetre(true);
    if (cfg.mkOuvert) ouvrirMarche(true);
    if (cfg.odOuvert) ouvrirOrdres(true);
    window.addEventListener('resize', () => { placerPanneau(); placerWidget(); placerFenetre(); placerMarche(); placerOrdres(); });
})();