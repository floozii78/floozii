// ==UserScript==
// @name         GrepoPlus
// @namespace    GrepoPlus
// @description  BOT for Grepolis
// @version      1.0
// @match        https://*.grepolis.com/game/*
// @match        http://*.grepolis.com/game/*
// @grant        GM_xmlhttpRequest
// @connect      grepoplus.duckdns.org
// @run-at       document-start
// ==/UserScript==

(function () {
    try {
        var _root = document.documentElement || document;
        if (_root.getAttribute && _root.getAttribute("data-grepoplus-loader") === "1") return;
        if (_root.setAttribute) _root.setAttribute("data-grepoplus-loader", "1");
    } catch (_eGuard) {}

    var VPS_BASE  = 'https://grepoplus.duckdns.org/bot';
    var BRIDGE_ID = 'gfbot_' + Math.random().toString(36).slice(2);
    var EVT_REQ   = BRIDGE_ID + '_req';
    var EVT_RES   = BRIDGE_ID + '_res';

    document.addEventListener(EVT_REQ, function (e) {
        var p = (typeof e.detail === 'object') ? e.detail : JSON.parse(e.detail);
        GM_xmlhttpRequest({
            method : p.method || 'GET',
            url    : p.url,
            data   : p.data || null,
            headers: p.headers || {},
            onload : function (r) {
                var out = { id: p.id, status: r.status, text: r.responseText };
                document.dispatchEvent(new CustomEvent(EVT_RES, {
                    detail : (typeof cloneInto === 'function') ? cloneInto(out, document) : out,
                    bubbles: true
                }));
            },
            onerror: function () {
                var out = { id: p.id, status: 0, text: '' };
                document.dispatchEvent(new CustomEvent(EVT_RES, {
                    detail : (typeof cloneInto === 'function') ? cloneInto(out, document) : out,
                    bubbles: true
                }));
            }
        });
    });

    var bootCode = null;
    var domReady = false;

    function tryInject() {
        if (!bootCode || !domReady) return;

        var cfg = document.createElement('script');
        cfg.textContent = [
            'window._GFBOT_BRIDGE_ID = ' + JSON.stringify(BRIDGE_ID) + ';',
            'window._GFBOT_VPS_BASE  = ' + JSON.stringify(VPS_BASE)  + ';'
        ].join('\n');
        (document.head || document.documentElement).appendChild(cfg);

        var blob = new Blob([bootCode], { type: 'application/javascript' });
        var url  = URL.createObjectURL(blob);
        var s    = document.createElement('script');
        s.src    = url;
        s.onload = function () { URL.revokeObjectURL(url); };
        (document.head || document.documentElement).appendChild(s);
    }

    document.addEventListener('DOMContentLoaded', function () {
        domReady = true;
        tryInject();
    });

    GM_xmlhttpRequest({
        method: 'GET',
        url   : VPS_BASE + '/boot.js?v=' + Date.now(),
        onload: function (r) {
            if (r.status !== 200) return;
            bootCode = r.responseText;
            tryInject();
        },
        onerror: function () {}
    });

})();